#!/usr/bin/env python
# -*- coding: utf-8 -*-
# create by tianchao 2018年 4月20日 星期五 11时12分16秒 CST

import os
import re
import aliyun

if __name__ == '__main__':

    result = os.popen('curl ip.cn').read()
    pattern = re.compile(r'(?<![\.\d])(?:\d{1,3}\.){3}\d{1,3}(?![\.\d])')
    ips = re.findall(pattern, result)
    if len(ips) == 1:
        aliyun.changeDomainAnalysis(ips[0])

