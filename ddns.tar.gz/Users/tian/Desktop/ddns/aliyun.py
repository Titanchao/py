#!/usr/bin/env python
# -*- coding: utf-8 -*-

import requests
import uuid
import datetime
import json
import hmac
import hashlib
import base64
import urllib

apiStr = 'https://alidns.aliyuncs.com'

def percent_encode(encodeStr):
    encodeStr = str(encodeStr)
    res = urllib.quote(encodeStr)
    res = res.replace('+', '%20')
    res = res.replace('*', '%2A')
    res = res.replace('%7E', '~')
    return res

def commonParams():
    params = {}
    params["Format"] = "json"
    params["Version"] = "2015-01-09"
    params["AccessKeyId"] = "LTAIxjVN7kGqvqs0"
    params["SignatureMethod"] = "HMAC-SHA1"
    params["Timestamp"] = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
    params["SignatureVersion"] = "1.0"
    params["SignatureNonce"] = str(uuid.uuid1())
    return params

def createSignature(params):
    sortedParam = sorted(params.items(), key=lambda params: params[0])
    queryStr = ""
    for (k, v) in sortedParam:
        queryStr += "&" + percent_encode(k) + "=" + percent_encode(v)

    stringToSign = "GET&%2F&" + percent_encode(queryStr[1:])
    bkey = b'lFC4Hct4Hn0o1LpmtbTAa36zZcuQOp&'
    bstr = stringToSign.encode('utf-8')
    h = hmac.new(bkey, bstr, hashlib.sha1)
    signature = base64.b64encode(h.digest()).strip()
    return signature


def getAllDomains():
    params = commonParams()
    params['Action'] = 'DescribeDomainRecords'
    params['DomainName'] = 'bitsnail.com'
    params["Signature"] = createSignature(params)
    response = requests.get(apiStr, params)
    if response.status_code == 200:
        return response.json()
    else:
        return None


def changeDomainAnalysis(ip):
    result = getAllDomains()
    record = result['DomainRecords']['Record']
    idstr = None
    for dict in record:
        if dict['DomainName'] == 'bitsnail.com':
            print(dict)
            idstr = dict['RecordId']
            break

    if idstr is not None:
        params = commonParams()
        params['Action'] = 'UpdateDomainRecord'
        params['RecordId'] = idstr
        params['RR'] = '*'
        params['Type'] = 'A'
        params['Value'] = ip
        params["Signature"] = createSignature(params)
        response = requests.get(apiStr, params)
        print(response.status_code)
        print(response.json())

if __name__ == '__main__':
    changeDomainAnalysis('0.0.0.0')
